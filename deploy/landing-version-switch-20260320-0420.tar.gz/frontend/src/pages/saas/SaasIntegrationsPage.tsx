import { useEffect, useState } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import toast from 'react-hot-toast';
import {
  saasApi,
  type LandingCarouselItem,
  type SaasPlatformSettings,
  type SaasPlatformSettingsUpdate,
} from '../../api/saas';

type FormState = {
  brand_name: string;
  public_site_url: string;
  yandex_webmaster_verification: string;
  yandex_metrika_counter_id: string;
  yandex_metrika_tag: string;
  google_analytics_measurement_id: string;
  google_tag_manager_id: string;
  yandex_rsy_site_id: string;
  yandex_rsy_block_id: string;
  yandex_rsy_script: string;
  custom_head_html: string;
  custom_body_html: string;
  yookassa_shop_id: string;
  yookassa_secret_key: string;
  yookassa_return_url: string;
};

const EMPTY_FORM: FormState = {
  brand_name: '',
  public_site_url: '',
  yandex_webmaster_verification: '',
  yandex_metrika_counter_id: '',
  yandex_metrika_tag: '',
  google_analytics_measurement_id: '',
  google_tag_manager_id: '',
  yandex_rsy_site_id: '',
  yandex_rsy_block_id: '',
  yandex_rsy_script: '',
  custom_head_html: '',
  custom_body_html: '',
  yookassa_shop_id: '',
  yookassa_secret_key: '',
  yookassa_return_url: '',
};

function isFilled(v: string | undefined | null): boolean {
  return Boolean((v || '').trim());
}

function StatusBadge({ ok, label }: { ok: boolean; label: string }) {
  return (
    <span
      className={`inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-xs font-semibold border ${
        ok
          ? 'bg-emerald-500/15 text-emerald-300 border-emerald-500/30'
          : 'bg-slate-600/20 text-slate-300 border-slate-500/40'
      }`}
    >
      <span aria-hidden>{ok ? '●' : '○'}</span>
      {label}
    </span>
  );
}

function Accordion({
  title,
  badge,
  defaultOpen = false,
  children,
}: {
  title: string;
  badge?: React.ReactNode;
  defaultOpen?: boolean;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);
  return (
    <section className="rounded-xl border border-slate-700 bg-slate-800 overflow-hidden">
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        className="w-full flex items-center justify-between px-5 py-3.5 hover:bg-slate-700/40 transition-colors"
      >
        <div className="flex items-center gap-3">
          <h2 className="text-lg font-semibold text-white">{title}</h2>
          {badge}
        </div>
        <span className={`text-slate-400 text-xl transition-transform ${open ? 'rotate-180' : ''}`}>▾</span>
      </button>
      {open && <div className="px-5 pb-5 space-y-4">{children}</div>}
    </section>
  );
}

function mapSettingsToForm(data: SaasPlatformSettings): FormState {
  return {
    brand_name: data.brand_name || '',
    public_site_url: data.public_site_url || '',
    yandex_webmaster_verification: data.yandex_webmaster_verification || '',
    yandex_metrika_counter_id: data.yandex_metrika_counter_id || '',
    yandex_metrika_tag: data.yandex_metrika_tag || '',
    google_analytics_measurement_id: data.google_analytics_measurement_id || '',
    google_tag_manager_id: data.google_tag_manager_id || '',
    yandex_rsy_site_id: data.yandex_rsy_site_id || '',
    yandex_rsy_block_id: data.yandex_rsy_block_id || '',
    yandex_rsy_script: data.yandex_rsy_script || '',
    custom_head_html: data.custom_head_html || '',
    custom_body_html: data.custom_body_html || '',
    yookassa_shop_id: data.yookassa_shop_id || '',
    yookassa_secret_key: '',
    yookassa_return_url: data.yookassa_return_url || '',
  };
}

export default function SaasIntegrationsPage() {
  const queryClient = useQueryClient();
  const [form, setForm] = useState<FormState>(EMPTY_FORM);
  const [hasSecret, setHasSecret] = useState(false);
  const [carouselCategories, setCarouselCategories] = useState<string[]>([]);
  const [carouselItems, setCarouselItems] = useState<LandingCarouselItem[]>([]);
  const [defaultCategory, setDefaultCategory] = useState('');
  const [landingDefaultVersion, setLandingDefaultVersion] = useState<'v1' | 'v2'>('v2');
  const [privateReviews, setPrivateReviews] = useState<Array<{ author: string; text: string; avatar?: string }>>([]);
  const [companyReviews, setCompanyReviews] = useState<Array<{ company: string; text: string; logo: string }>>([]);
  const [pendingReviews, setPendingReviews] = useState<Array<{
    id: string;
    review_type: 'private' | 'company';
    author?: string;
    company?: string;
    text: string;
    avatar_or_logo?: string;
    status?: string;
    created_at?: string;
  }>>([]);
  const [leadRequests, setLeadRequests] = useState<Array<{
    id: string;
    name: string;
    contact: string;
    message?: string;
    status?: string;
    source?: string;
    created_at?: string;
  }>>([]);
  const [newCategory, setNewCategory] = useState('');
  const [uploadingIndex, setUploadingIndex] = useState<number | null>(null);

  const { data, isLoading, refetch } = useQuery({
    queryKey: ['saas-platform-settings'],
    queryFn: saasApi.getPlatformSettings,
  });

  const hydrateCarousel = (src: SaasPlatformSettings) => {
    setCarouselCategories(
      Array.isArray(src.landing_media_categories)
        ? src.landing_media_categories.filter((x) => String(x || '').trim())
        : [],
    );
    setCarouselItems(
      Array.isArray(src.landing_media_carousel)
        ? src.landing_media_carousel
            .filter((item) => item && String(item.category || '').trim())
            .map((item) => ({
              id: item.id || crypto.randomUUID(),
              category: item.category,
              title: item.title || '',
              description: item.description || '',
              media_type: item.media_type === 'video' ? 'video' : 'image',
              media_url: item.media_url || '',
            }))
        : [],
    );
    setDefaultCategory(src.default_landing_category || '');
    setLandingDefaultVersion(src.landing_default_version === 'v1' ? 'v1' : 'v2');
    setPrivateReviews(Array.isArray(src.landing_private_reviews) ? src.landing_private_reviews : []);
    setCompanyReviews(Array.isArray(src.landing_company_reviews) ? src.landing_company_reviews : []);
    setPendingReviews(Array.isArray(src.landing_pending_reviews) ? src.landing_pending_reviews : []);
    setLeadRequests(Array.isArray(src.landing_lead_requests) ? src.landing_lead_requests : []);
  };

  useEffect(() => {
    if (!data) return;
    setForm(mapSettingsToForm(data));
    setHasSecret(Boolean(data.has_yookassa_secret));
    hydrateCarousel(data);
  }, [data]);

  const mutation = useMutation({
    mutationFn: (payload: SaasPlatformSettingsUpdate) => saasApi.updatePlatformSettings(payload),
    onSuccess: (updated) => {
      queryClient.setQueryData(['saas-platform-settings'], updated);
      setForm(mapSettingsToForm(updated));
      setHasSecret(Boolean(updated.has_yookassa_secret));
      hydrateCarousel(updated);
      toast.success('Настройки сохранены');
    },
    onError: (err: unknown) => {
      const msg =
        (err as { response?: { data?: { detail?: string } } })?.response?.data?.detail ||
        'Не удалось сохранить';
      toast.error(msg);
    },
  });

  const setField = <K extends keyof FormState>(key: K, value: FormState[K]) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const categories = carouselCategories.map((x) => x.trim()).filter(Boolean);
    const carousel = carouselItems
      .map((item) => ({
        ...item,
        category: item.category.trim(),
        title: (item.title || '').trim(),
        description: (item.description || '').trim(),
        media_url: item.media_url.trim(),
      }))
      .filter((item) => item.category && item.media_url);
    const payload: SaasPlatformSettingsUpdate = {
      brand_name: form.brand_name,
      public_site_url: form.public_site_url,
      yandex_webmaster_verification: form.yandex_webmaster_verification,
      yandex_metrika_counter_id: form.yandex_metrika_counter_id,
      yandex_metrika_tag: form.yandex_metrika_tag,
      google_analytics_measurement_id: form.google_analytics_measurement_id,
      google_tag_manager_id: form.google_tag_manager_id,
      yandex_rsy_site_id: form.yandex_rsy_site_id,
      yandex_rsy_block_id: form.yandex_rsy_block_id,
      yandex_rsy_script: form.yandex_rsy_script,
      custom_head_html: form.custom_head_html,
      custom_body_html: form.custom_body_html,
      landing_media_categories: categories,
      landing_media_carousel: carousel,
      default_landing_category: defaultCategory,
      landing_default_version: landingDefaultVersion,
      landing_private_reviews: privateReviews,
      landing_company_reviews: companyReviews,
      landing_pending_reviews: pendingReviews,
      landing_lead_requests: leadRequests,
      yookassa_shop_id: form.yookassa_shop_id,
      yookassa_secret_key: form.yookassa_secret_key,
      yookassa_return_url: form.yookassa_return_url,
    };
    mutation.mutate(payload);
  };

  if (isLoading) {
    return <div className="text-slate-300">Загрузка интеграций...</div>;
  }

  const statusYandexWebmaster = isFilled(form.yandex_webmaster_verification);
  const statusYandexMetrika = isFilled(form.yandex_metrika_counter_id) || isFilled(form.yandex_metrika_tag);
  const statusGoogleAnalytics = isFilled(form.google_analytics_measurement_id) || isFilled(form.google_tag_manager_id);
  const statusRsy = (isFilled(form.yandex_rsy_site_id) && isFilled(form.yandex_rsy_block_id)) || isFilled(form.yandex_rsy_script);
  const statusYookassa = isFilled(form.yookassa_shop_id) && hasSecret;
  const statusCustomHead = isFilled(form.custom_head_html);
  const statusCustomBody = isFilled(form.custom_body_html);
  const statusLandingMedia = carouselCategories.length > 0 && carouselItems.length > 0;

  const addCategory = () => {
    const value = newCategory.trim();
    if (!value) return;
    if (carouselCategories.includes(value)) { toast.error('Категория уже есть'); return; }
    setCarouselCategories((prev) => [...prev, value]);
    setNewCategory('');
  };
  const removeCategory = (category: string) => {
    setCarouselCategories((prev) => prev.filter((c) => c !== category));
    setCarouselItems((prev) => prev.filter((item) => item.category !== category));
  };
  const addCarouselItem = () => {
    const category = carouselCategories[0] || '';
    if (!category) { toast.error('Сначала добавьте категорию'); return; }
    setCarouselItems((prev) => [...prev, { id: crypto.randomUUID(), category, title: '', description: '', media_type: 'image', media_url: '' }]);
  };
  const updateCarouselItem = <K extends keyof LandingCarouselItem>(i: number, key: K, value: LandingCarouselItem[K]) => {
    setCarouselItems((prev) => prev.map((item, idx) => (idx === i ? { ...item, [key]: value } : item)));
  };
  const moveItem = (i: number, dir: -1 | 1) => {
    const t = i + dir;
    if (t < 0 || t >= carouselItems.length) return;
    const c = [...carouselItems]; [c[i], c[t]] = [c[t], c[i]]; setCarouselItems(c);
  };
  const removeItem = (i: number) => setCarouselItems((prev) => prev.filter((_, idx) => idx !== i));
  const approvePending = (id: string) => {
    const p = pendingReviews.find((x) => x.id === id);
    if (!p) return;
    if (p.review_type === 'company') {
      setCompanyReviews((prev) => [
        ...prev,
        { company: p.company || 'Компания', text: p.text, logo: p.avatar_or_logo || '/OS_LOGO.png?v=20260320' },
      ]);
    } else {
      setPrivateReviews((prev) => [
        ...prev,
        { author: p.author || 'Пользователь', text: p.text, avatar: p.avatar_or_logo || '' },
      ]);
    }
    setPendingReviews((prev) => prev.filter((x) => x.id !== id));
  };
  const rejectPending = (id: string) => setPendingReviews((prev) => prev.filter((x) => x.id !== id));
  const uploadMediaForItem = async (i: number, file: File | null) => {
    if (!file) return;
    try {
      setUploadingIndex(i);
      const res = await saasApi.uploadLandingMedia(file);
      updateCarouselItem(i, 'media_url', res.url);
      updateCarouselItem(i, 'media_type', file.type.startsWith('video/') ? 'video' : 'image');
      toast.success('Файл загружен');
    } catch { toast.error('Ошибка загрузки'); } finally { setUploadingIndex(null); }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-white">Интеграции и маркетинг</h1>
        <p className="text-slate-400 mt-1 text-sm">Все секции сворачиваются — кликните на заголовок.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          <StatusBadge ok={statusYandexWebmaster} label="Яндекс Вебмастер" />
          <StatusBadge ok={statusYandexMetrika} label="Яндекс Метрика" />
          <StatusBadge ok={statusGoogleAnalytics} label="Google Analytics / GTM" />
          <StatusBadge ok={statusRsy} label="РСЯ" />
          <StatusBadge ok={statusYookassa} label="ЮKassa" />
          <StatusBadge ok={statusCustomHead} label="Custom HEAD" />
          <StatusBadge ok={statusCustomBody} label="Custom BODY" />
          <StatusBadge ok={statusLandingMedia} label={`Карусель: ${carouselCategories.length} кат. / ${carouselItems.length} эл.`} />
        </div>
      </div>

      <form onSubmit={onSubmit} className="space-y-3">
        {/* ───── Бренд ───── */}
        <Accordion title="Бренд и сайт">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Название продукта</span>
              <input value={form.brand_name} onChange={(e) => setField('brand_name', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" placeholder="AntExpress" />
            </label>
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Публичный URL сайта</span>
              <input value={form.public_site_url} onChange={(e) => setField('public_site_url', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" placeholder="https://antexpress.ru" />
            </label>
            <label className="space-y-1 text-sm md:col-span-2">
              <span className="text-slate-300">Лендинг по умолчанию (`/landing`)</span>
              <div className="flex gap-4 mt-1">
                <label className="inline-flex items-center gap-2 text-slate-200">
                  <input
                    type="radio"
                    name="landing-default-version"
                    checked={landingDefaultVersion === 'v1'}
                    onChange={() => setLandingDefaultVersion('v1')}
                  />
                  Landing 1 (классический)
                </label>
                <label className="inline-flex items-center gap-2 text-slate-200">
                  <input
                    type="radio"
                    name="landing-default-version"
                    checked={landingDefaultVersion === 'v2'}
                    onChange={() => setLandingDefaultVersion('v2')}
                  />
                  Landing 2 (новый)
                </label>
              </div>
            </label>
          </div>
        </Accordion>

        {/* ───── Яндекс ───── */}
        <Accordion title="Яндекс: Вебмастер, Метрика, РСЯ" badge={<StatusBadge ok={statusYandexWebmaster || statusYandexMetrika || statusRsy} label={statusYandexWebmaster || statusYandexMetrika || statusRsy ? 'есть' : 'не настроено'} />}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="space-y-1 text-sm"><span className="text-slate-300">Токен Яндекс Вебмастер</span><input value={form.yandex_webmaster_verification} onChange={(e) => setField('yandex_webmaster_verification', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
            <label className="space-y-1 text-sm"><span className="text-slate-300">ID Яндекс.Метрики</span><input value={form.yandex_metrika_counter_id} onChange={(e) => setField('yandex_metrika_counter_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
            <label className="space-y-1 text-sm"><span className="text-slate-300">ID площадки РСЯ</span><input value={form.yandex_rsy_site_id} onChange={(e) => setField('yandex_rsy_site_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
            <label className="space-y-1 text-sm"><span className="text-slate-300">ID блока РСЯ</span><input value={form.yandex_rsy_block_id} onChange={(e) => setField('yandex_rsy_block_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
          </div>
          <label className="space-y-1 text-sm block"><span className="text-slate-300">Код Яндекс.Метрики (HTML/JS)</span><textarea value={form.yandex_metrika_tag} onChange={(e) => setField('yandex_metrika_tag', e.target.value)} rows={3} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white font-mono text-xs" /></label>
          <label className="space-y-1 text-sm block"><span className="text-slate-300">Код РСЯ (HTML/JS)</span><textarea value={form.yandex_rsy_script} onChange={(e) => setField('yandex_rsy_script', e.target.value)} rows={3} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white font-mono text-xs" /></label>
        </Accordion>

        {/* ───── Google ───── */}
        <Accordion title="Google аналитика" badge={<StatusBadge ok={statusGoogleAnalytics} label={statusGoogleAnalytics ? 'подключено' : 'не настроено'} />}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="space-y-1 text-sm"><span className="text-slate-300">GA Measurement ID</span><input value={form.google_analytics_measurement_id} onChange={(e) => setField('google_analytics_measurement_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" placeholder="G-XXXXXXXXXX" /></label>
            <label className="space-y-1 text-sm"><span className="text-slate-300">GTM ID</span><input value={form.google_tag_manager_id} onChange={(e) => setField('google_tag_manager_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" placeholder="GTM-XXXXXXX" /></label>
          </div>
        </Accordion>

        {/* ───── ЮKassa ───── */}
        <Accordion title="ЮKassa" badge={<StatusBadge ok={statusYookassa} label={statusYookassa ? 'подключено' : 'не настроено'} />}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <label className="space-y-1 text-sm"><span className="text-slate-300">Shop ID</span><input value={form.yookassa_shop_id} onChange={(e) => setField('yookassa_shop_id', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
            <label className="space-y-1 text-sm"><span className="text-slate-300">Return URL</span><input value={form.yookassa_return_url} onChange={(e) => setField('yookassa_return_url', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" /></label>
          </div>
          <label className="space-y-1 text-sm block"><span className="text-slate-300">Secret Key {hasSecret ? '(установлен)' : '(не задан)'}</span><input type="password" value={form.yookassa_secret_key} onChange={(e) => setField('yookassa_secret_key', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white" placeholder="Пустое = не менять" /></label>
        </Accordion>

        {/* ───── Custom HTML ───── */}
        <Accordion title="Пользовательские HTML вставки" badge={<StatusBadge ok={statusCustomHead || statusCustomBody} label={statusCustomHead || statusCustomBody ? 'есть' : 'пусто'} />}>
          <label className="space-y-1 text-sm block"><span className="text-slate-300">Код в &lt;head&gt;</span><textarea value={form.custom_head_html} onChange={(e) => setField('custom_head_html', e.target.value)} rows={3} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white font-mono text-xs" /></label>
          <label className="space-y-1 text-sm block"><span className="text-slate-300">Код перед &lt;/body&gt;</span><textarea value={form.custom_body_html} onChange={(e) => setField('custom_body_html', e.target.value)} rows={3} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white font-mono text-xs" /></label>
        </Accordion>

        {/* ───── Карусель ───── */}
        <Accordion
          title="Учебная карусель на лендинге"
          badge={<StatusBadge ok={statusLandingMedia} label={`${carouselCategories.length} кат. / ${carouselItems.length} эл.`} />}
        >
          {/* Категории */}
          <div className="rounded-lg border border-slate-600 p-3 space-y-3">
            <p className="text-sm text-slate-200 font-medium">Категории</p>
            <div className="flex flex-wrap gap-2">
              {carouselCategories.map((cat) => {
                const isDefault = defaultCategory === cat;
                return (
                  <span key={cat} className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs text-white ${isDefault ? 'bg-fuchsia-600/60 ring-1 ring-fuchsia-400' : 'bg-slate-700'}`}>
                    <button
                      type="button"
                      onClick={() => setDefaultCategory(isDefault ? '' : cat)}
                      className={`transition-colors ${isDefault ? 'text-yellow-300' : 'text-slate-400 hover:text-yellow-300'}`}
                      title={isDefault ? 'Снять «по умолчанию»' : 'Сделать категорией по умолчанию'}
                    >
                      {isDefault ? '★' : '☆'}
                    </button>
                    {cat}
                    <button type="button" onClick={() => { removeCategory(cat); if (isDefault) setDefaultCategory(''); }} className="text-rose-300 hover:text-white" aria-label={`Удалить ${cat}`}>✕</button>
                  </span>
                );
              })}
              {!carouselCategories.length && <span className="text-xs text-slate-500">Нет категорий. На лендинге используются дефолтные.</span>}
            </div>
            {defaultCategory && <p className="text-xs text-fuchsia-300">★ По умолчанию на лендинге: <strong>{defaultCategory}</strong></p>}
            <div className="flex gap-2">
              <input
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addCategory())}
                placeholder="Новая категория..."
                className="flex-1 rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm"
              />
              <button type="button" onClick={addCategory} className="px-4 py-2 rounded-lg bg-slate-700 text-white hover:bg-slate-600 text-sm shrink-0">+ Категория</button>
            </div>
          </div>

          {/* Элементы */}
          <div className="rounded-lg border border-slate-600 p-3 space-y-3">
            <div className="flex items-center justify-between">
              <p className="text-sm text-slate-200 font-medium">Элементы карусели ({carouselItems.length})</p>
              <button type="button" onClick={addCarouselItem} className="px-3 py-1.5 rounded-lg bg-fuchsia-600/70 text-white hover:bg-fuchsia-500 text-sm">+ Элемент</button>
            </div>
            {!carouselItems.length && <p className="text-xs text-slate-500">Нет элементов. На лендинге используются дефолтные изображения.</p>}

            <div className="space-y-2">
              {carouselItems.map((item, idx) => (
                <CarouselItemCard
                  key={item.id || idx}
                  item={item}
                  index={idx}
                  total={carouselItems.length}
                  categories={carouselCategories}
                  uploading={uploadingIndex === idx}
                  onUpdate={(key, value) => updateCarouselItem(idx, key, value)}
                  onMove={(dir) => moveItem(idx, dir)}
                  onRemove={() => removeItem(idx)}
                  onUpload={(file) => void uploadMediaForItem(idx, file)}
                />
              ))}
            </div>
          </div>
        </Accordion>

        <Accordion
          title="Отзывы и заявки с лендинга"
          badge={<StatusBadge ok={privateReviews.length + companyReviews.length > 0} label={`Отзывы: ${privateReviews.length + companyReviews.length} / Черновики: ${pendingReviews.length} / Заявки: ${leadRequests.length}`} />}
        >
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-3">
            <div className="rounded-lg border border-slate-600 p-3 space-y-2">
              <p className="text-sm text-slate-200 font-medium">Частные отзывы (публикация)</p>
              {privateReviews.map((r, i) => (
                <div key={`${r.author}-${i}`} className="rounded-lg border border-slate-700 p-2 space-y-2">
                  <input value={r.author} onChange={(e) => setPrivateReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, author: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="Автор" />
                  <input value={r.text} onChange={(e) => setPrivateReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, text: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="Текст" />
                  <input value={r.avatar || ''} onChange={(e) => setPrivateReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, avatar: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="URL аватара" />
                  <button type="button" onClick={() => setPrivateReviews((prev) => prev.filter((_, idx) => idx !== i))} className="px-2 py-1 rounded bg-rose-600/70 text-xs text-white">Удалить</button>
                </div>
              ))}
              <button type="button" onClick={() => setPrivateReviews((prev) => [...prev, { author: '', text: '', avatar: '' }])} className="px-3 py-1.5 rounded bg-slate-700 text-sm text-white">+ Добавить частный отзыв</button>
            </div>
            <div className="rounded-lg border border-slate-600 p-3 space-y-2">
              <p className="text-sm text-slate-200 font-medium">Корпоративные отзывы (публикация)</p>
              {companyReviews.map((r, i) => (
                <div key={`${r.company}-${i}`} className="rounded-lg border border-slate-700 p-2 space-y-2">
                  <input value={r.company} onChange={(e) => setCompanyReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, company: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="Компания" />
                  <input value={r.text} onChange={(e) => setCompanyReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, text: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="Текст" />
                  <input value={r.logo} onChange={(e) => setCompanyReviews((prev) => prev.map((x, idx) => idx === i ? { ...x, logo: e.target.value } : x))} className="w-full rounded border border-slate-600 bg-slate-900 px-2 py-1 text-sm text-white" placeholder="URL логотипа" />
                  <button type="button" onClick={() => setCompanyReviews((prev) => prev.filter((_, idx) => idx !== i))} className="px-2 py-1 rounded bg-rose-600/70 text-xs text-white">Удалить</button>
                </div>
              ))}
              <button type="button" onClick={() => setCompanyReviews((prev) => [...prev, { company: '', text: '', logo: '' }])} className="px-3 py-1.5 rounded bg-slate-700 text-sm text-white">+ Добавить отзыв компании</button>
            </div>
          </div>

          <div className="rounded-lg border border-slate-600 p-3 space-y-2">
            <p className="text-sm text-slate-200 font-medium">Черновики отзывов (с формы лендинга)</p>
            {!pendingReviews.length && <p className="text-xs text-slate-500">Пока нет черновиков.</p>}
            {pendingReviews.map((r) => (
              <div key={r.id} className="rounded-lg border border-slate-700 p-2">
                <p className="text-xs text-slate-400 mb-1">{r.review_type === 'company' ? 'Компания' : 'Частный'} · {r.created_at || ''}</p>
                <p className="text-sm text-white">{r.text}</p>
                <p className="text-xs text-slate-300 mt-1">{r.author || r.company}</p>
                <div className="mt-2 flex gap-2">
                  <button type="button" onClick={() => approvePending(r.id)} className="px-2 py-1 rounded bg-emerald-600/80 text-xs text-white">Опубликовать</button>
                  <button type="button" onClick={() => rejectPending(r.id)} className="px-2 py-1 rounded bg-rose-600/80 text-xs text-white">Отклонить</button>
                </div>
              </div>
            ))}
          </div>

          <div className="rounded-lg border border-slate-600 p-3 space-y-2">
            <p className="text-sm text-slate-200 font-medium">Заявки (с формы лендинга)</p>
            {!leadRequests.length && <p className="text-xs text-slate-500">Пока нет заявок.</p>}
            {leadRequests.slice().reverse().map((l) => (
              <div key={l.id} className="rounded-lg border border-slate-700 p-2">
                <p className="text-xs text-slate-400">{l.created_at || ''} · {l.source || 'landing'}</p>
                <p className="text-sm text-white">{l.name} — {l.contact}</p>
                {l.message && <p className="text-xs text-slate-300 mt-1">{l.message}</p>}
              </div>
            ))}
          </div>
        </Accordion>

        {/* ───── Кнопки ───── */}
        <div className="flex items-center gap-3 pt-2">
          <button type="submit" disabled={mutation.isPending} className="px-5 py-2.5 rounded-lg bg-red-600 text-white font-semibold hover:bg-red-500 disabled:opacity-50">
            {mutation.isPending ? 'Сохраняю...' : 'Сохранить все настройки'}
          </button>
          <button type="button" onClick={() => refetch()} className="px-4 py-2 rounded-lg border border-slate-600 text-slate-200 hover:bg-slate-700">Обновить</button>
        </div>
      </form>
    </div>
  );
}

function CarouselItemCard({
  item,
  index,
  total,
  categories,
  uploading,
  onUpdate,
  onMove,
  onRemove,
  onUpload,
}: {
  item: LandingCarouselItem;
  index: number;
  total: number;
  categories: string[];
  uploading: boolean;
  onUpdate: <K extends keyof LandingCarouselItem>(key: K, value: LandingCarouselItem[K]) => void;
  onMove: (dir: -1 | 1) => void;
  onRemove: () => void;
  onUpload: (file: File) => void;
}) {
  const [expanded, setExpanded] = useState(!item.media_url);
  const hasThumb = Boolean(item.media_url);

  return (
    <div className="rounded-lg border border-slate-600 bg-slate-900/50 overflow-hidden">
      <button
        type="button"
        onClick={() => setExpanded((v) => !v)}
        className="w-full flex items-center gap-3 px-3 py-2 hover:bg-slate-700/30 transition-colors"
      >
        {hasThumb && item.media_type === 'image' && (
          <img src={item.media_url} alt="" className="w-12 h-8 rounded object-cover shrink-0 bg-black" />
        )}
        {hasThumb && item.media_type === 'video' && (
          <span className="w-12 h-8 rounded bg-black flex items-center justify-center text-xs text-white shrink-0">▶</span>
        )}
        {!hasThumb && (
          <span className="w-12 h-8 rounded bg-slate-700 flex items-center justify-center text-xs text-slate-400 shrink-0">?</span>
        )}
        <div className="flex-1 text-left min-w-0">
          <p className="text-sm text-white truncate">{item.title || `Элемент #${index + 1}`}</p>
          <p className="text-[10px] text-slate-400">{item.category} · {item.media_type}</p>
        </div>
        <div className="flex items-center gap-1 shrink-0" onClick={(e) => e.stopPropagation()}>
          {index > 0 && <button type="button" onClick={() => onMove(-1)} className="px-1.5 py-0.5 rounded bg-slate-700 text-[10px] text-white">↑</button>}
          {index < total - 1 && <button type="button" onClick={() => onMove(1)} className="px-1.5 py-0.5 rounded bg-slate-700 text-[10px] text-white">↓</button>}
          <button type="button" onClick={onRemove} className="px-1.5 py-0.5 rounded bg-rose-600/70 text-[10px] text-white">✕</button>
        </div>
        <span className={`text-slate-400 text-sm transition-transform ${expanded ? 'rotate-180' : ''}`}>▾</span>
      </button>

      {expanded && (
        <div className="px-3 pb-3 pt-1 space-y-3 border-t border-slate-700">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Категория</span>
              <select value={item.category} onChange={(e) => onUpdate('category', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm">
                {categories.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </label>
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Тип</span>
              <select value={item.media_type} onChange={(e) => onUpdate('media_type', e.target.value as 'image' | 'video')} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm">
                <option value="image">Изображение</option>
                <option value="video">Видео</option>
              </select>
            </label>
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Заголовок</span>
              <input value={item.title || ''} onChange={(e) => onUpdate('title', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm" />
            </label>
            <label className="space-y-1 text-sm">
              <span className="text-slate-300">Описание</span>
              <input value={item.description || ''} onChange={(e) => onUpdate('description', e.target.value)} className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm" />
            </label>
          </div>
          <label className="space-y-1 text-sm block">
            <span className="text-slate-300">URL медиа</span>
            <input value={item.media_url} onChange={(e) => onUpdate('media_url', e.target.value)} placeholder="/media/..." className="w-full rounded-lg border border-slate-600 bg-slate-900 px-3 py-2 text-white text-sm" />
          </label>
          <div className="flex items-center gap-3">
            <label className="px-3 py-1.5 rounded-lg border border-slate-500 text-sm text-slate-100 cursor-pointer hover:bg-slate-700">
              {uploading ? 'Загрузка...' : 'Загрузить файл'}
              <input type="file" accept="image/*,video/*" className="hidden" onChange={(e) => { const f = e.target.files?.[0]; if (f) onUpload(f); e.currentTarget.value = ''; }} />
            </label>
            {hasThumb && <span className="text-xs text-emerald-300">URL задан</span>}
          </div>
        </div>
      )}
    </div>
  );
}
