"""
Публичный API рекламы — GET /api/v1/marketing/ads/ с группировкой по слотам.
"""
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response
from django.conf import settings
from django.core.mail import send_mail
from django.utils import timezone

from apps.marketing.models import Advertisement
from apps.saas.models import SaasPlatformSettings
from .serializers import AdvertisementSerializer


SLOTS = [
    Advertisement.SLOT_SIDEBAR,
    Advertisement.SLOT_FOOTER_COL_1,
    Advertisement.SLOT_FOOTER_COL_2,
    Advertisement.SLOT_FOOTER_COL_3,
    Advertisement.SLOT_BLOG_CONTENT,
]


@api_view(['GET'])
@permission_classes([AllowAny])
def ads_grouped(request):
    """
    GET /api/v1/marketing/ads/
    Ответ: { "sidebar": [...], "footer_col_1": [...], "footer_col_2": [], "footer_col_3": [], "blog_content": [] }
    """
    qs = Advertisement.objects.filter(is_active=True)
    serializer = AdvertisementSerializer(qs, many=True, context={'request': request})
    data = list(serializer.data)
    result = {slot: [] for slot in SLOTS}
    for item in data:
        slot = item.get('slot')
        if slot in result:
            result[slot].append(item)
    return Response(result)


@api_view(['GET'])
@permission_classes([AllowAny])
def public_settings(request):
    """
    Публичные настройки для встраивания аналитики/маркетинга на фронтенде.
    Без секретов (secret keys не отдаются).
    """
    cfg = SaasPlatformSettings.get_solo()
    return Response(
        {
            'brand_name': cfg.brand_name or '',
            'public_site_url': cfg.public_site_url or '',
            'yandex_webmaster_verification': cfg.yandex_webmaster_verification or '',
            'yandex_metrika_counter_id': cfg.yandex_metrika_counter_id or '',
            'yandex_metrika_tag': cfg.yandex_metrika_tag or '',
            'google_analytics_measurement_id': cfg.google_analytics_measurement_id or '',
            'google_tag_manager_id': cfg.google_tag_manager_id or '',
            'yandex_rsy_site_id': cfg.yandex_rsy_site_id or '',
            'yandex_rsy_block_id': cfg.yandex_rsy_block_id or '',
            'yandex_rsy_script': cfg.yandex_rsy_script or '',
            'custom_head_html': cfg.custom_head_html or '',
            'custom_body_html': cfg.custom_body_html or '',
            'landing_media_categories': cfg.landing_media_categories or [],
            'landing_media_carousel': cfg.landing_media_carousel or [],
            'default_landing_category': cfg.default_landing_category or '',
            'landing_default_version': cfg.landing_default_version or 'v2',
            'landing_private_reviews': cfg.landing_private_reviews or [],
            'landing_company_reviews': cfg.landing_company_reviews or [],
        }
    )


def _notify_admin(subject: str, message: str) -> None:
    recipients = []
    env_recipient = getattr(settings, 'EMAIL_HOST_USER', '') or ''
    if env_recipient:
        recipients.append(env_recipient)
    if not recipients:
        return
    send_mail(
        subject=subject,
        message=message,
        from_email=getattr(settings, 'DEFAULT_FROM_EMAIL', None),
        recipient_list=recipients,
        fail_silently=True,
    )


@api_view(['POST'])
@permission_classes([AllowAny])
def submit_lead(request):
    cfg = SaasPlatformSettings.get_solo()
    payload = request.data if isinstance(request.data, dict) else {}

    name = str(payload.get('name') or '').strip()
    contact = str(payload.get('contact') or '').strip()
    message = str(payload.get('message') or '').strip()
    source = str(payload.get('source') or 'landing').strip() or 'landing'

    if not name or not contact:
        return Response({'detail': 'name and contact are required'}, status=400)

    leads = cfg.landing_lead_requests or []
    leads.append(
        {
            'id': timezone.now().strftime('%Y%m%d%H%M%S%f'),
            'name': name,
            'contact': contact,
            'message': message,
            'source': source,
            'status': 'new',
            'created_at': timezone.now().isoformat(),
        }
    )
    cfg.landing_lead_requests = leads[-500:]
    cfg.save(update_fields=['landing_lead_requests', 'updated_at'])

    _notify_admin(
        'Новая заявка с лендинга',
        f'Имя: {name}\nКонтакт: {contact}\nИсточник: {source}\nСообщение: {message}',
    )
    return Response({'ok': True}, status=201)


@api_view(['POST'])
@permission_classes([AllowAny])
def submit_review(request):
    cfg = SaasPlatformSettings.get_solo()
    payload = request.data if isinstance(request.data, dict) else {}

    review_type = str(payload.get('review_type') or 'private').strip().lower()
    if review_type not in ('private', 'company'):
        review_type = 'private'

    author = str(payload.get('author') or '').strip()
    text = str(payload.get('text') or '').strip()
    company = str(payload.get('company') or '').strip()
    avatar_or_logo = str(payload.get('avatar_or_logo') or '').strip()

    if not text:
        return Response({'detail': 'text is required'}, status=400)
    if review_type == 'private' and not author:
        return Response({'detail': 'author is required for private review'}, status=400)
    if review_type == 'company' and not company:
        return Response({'detail': 'company is required for company review'}, status=400)

    pending = cfg.landing_pending_reviews or []
    pending.append(
        {
            'id': timezone.now().strftime('%Y%m%d%H%M%S%f'),
            'review_type': review_type,
            'author': author,
            'company': company,
            'text': text,
            'avatar_or_logo': avatar_or_logo,
            'status': 'draft',
            'created_at': timezone.now().isoformat(),
        }
    )
    cfg.landing_pending_reviews = pending[-500:]
    cfg.save(update_fields=['landing_pending_reviews', 'updated_at'])

    _notify_admin(
        'Новый отзыв на модерацию',
        f'Тип: {review_type}\nАвтор: {author}\nКомпания: {company}\nТекст: {text}',
    )
    return Response({'ok': True}, status=201)
