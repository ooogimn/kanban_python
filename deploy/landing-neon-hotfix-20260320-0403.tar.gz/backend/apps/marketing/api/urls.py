from django.urls import path
from .views import ads_grouped, public_settings, submit_lead, submit_review

urlpatterns = [
    path('', ads_grouped),
    path('settings/', public_settings),
    path('lead/', submit_lead),
    path('review/', submit_review),
]
